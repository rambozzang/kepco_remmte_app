import 'dart:math';

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamp_remote_app/cntr/lifeCycle_controller.dart';
import 'package:lamp_remote_app/cntr/login_controller.dart';

import 'package:lamp_remote_app/route/app_pages.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final navigatorKey = GlobalKey<NavigatorState>();
  // D2Coding, Monaco, 'Courier New', monospace

  runApp(
    GetMaterialApp(
      title: "Application",
      navigatorKey: navigatorKey,
      theme: ThemeData(
        primaryColor: const Color(0Xff5965F5),
      ),
      builder: BotToastInit(),
      debugShowCheckedModeBanner: false,
      initialRoute: AppPages.INITIAL,
      initialBinding: BindingsBuilder(() {
        Get.put(LifecycleController());
        //  Get.put(LoginController());
      }),
      getPages: AppPages.routes,
    ),
  );
}
