class AuthConfig {
  // Kepco Auth App 호출에 필요한 데이터
  static bool prodServer = true;
  static const String callScheme = 'auth-callback';
  static const String siteCode = 'kepco';
  static const String otp = '567432';
  static const String subSystem = '13';
  static const String authtype = '2';
}
