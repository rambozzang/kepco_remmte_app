enum LoginStatus { none, login, appconfirm, callauth, authresult, background }
