import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamp_remote_app/cntr/login_controller.dart';
import 'package:lamp_remote_app/utils/enum.dart';

class LifecycleController extends FullLifeCycleController
    with FullLifeCycleMixin {
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onDetached() {
    debugPrint("--------------------------------------------------");
    debugPrint("onDetached!!");
    debugPrint("--------------------------------------------------");
  }

  // background 로 넘어갔을떄...
  @override
  void onInactive() {
    Get.find<LoginController>().isAuthProcessing.value = LoginStatus.background;
    debugPrint("--------------------------------------------------");
    debugPrint(
        "onInactive!!  ${Get.find<LoginController>().isAuthProcessing.value}");
    debugPrint("onInactive!!");
    debugPrint("--------------------------------------------------");
  }

  // background 로 넘어갔을떄...
  @override
  void onPaused() {
    debugPrint("--------------------------------------------------");
    debugPrint("onPaused!! ");
    debugPrint("--------------------------------------------------");
    Get.find<LoginController>().isAuthProcessing.value = LoginStatus.background;
  }

  // foreground 로 넘어갔을떄...
  @override
  void onResumed() {
    debugPrint("--------------------------------------------------");
    debugPrint("onResumed!!");
    debugPrint("--------------------------------------------------");
    Get.find<LoginController>().isAuthProcessing.value = LoginStatus.none;
  }

  // Optional
  @override
  Future<bool> didPushRoute(String route) {
    return super.didPushRoute(route);
  }

  // Optional
  @override
  Future<bool> didPopRoute() {
    print('HomeController - the current route will be closed');
    return super.didPopRoute();
  }

  // Optional
  @override
  void didChangeMetrics() {
    print('HomeController - the window size did change');
    super.didChangeMetrics();
  }

  // Optional
  @override
  void didChangePlatformBrightness() {
    print('HomeController - platform change ThemeMode');
    super.didChangePlatformBrightness();
  }
}
